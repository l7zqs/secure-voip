"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Loader2, Lock } from "lucide-react"
import { useRouter } from "next/navigation"
import dynamic from "next/dynamic"
import Link from "next/link"

// Dynamically import Lottie with no SSR to avoid hydration issues
const Lottie = dynamic(() => import("lottie-react"), { ssr: false })

export default function LoginForm() {
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [animation, setAnimation] = useState(null)
  const router = useRouter()

  // Load the animation JSON dynamically
  useEffect(() => {
    const loadAnimation = async () => {
      try {
        const animationData = await fetch("/welcome-animation.json").then((res) => res.json())
        setAnimation(animationData)
      } catch (err) {
        console.error("Failed to load animation:", err)
      }
    }

    loadAnimation()
  }, [])

  // This would be replaced with your actual authentication logic
  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    // Simulate API call
    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // For demo purposes, we'll use a hardcoded password
      // In a real app, you would validate against a secure backend
      if (password === "password123") {
        // Redirect to dashboard or home page after successful login
        router.push("/dashboard")
      } else {
        setError("Invalid password. Please try again.")
      }
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-md shadow-lg">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold text-center">Welcome Back</CardTitle>
        <div className="w-32 h-32 mx-auto">{animation && <Lottie animationData={animation} loop={true} />}</div>
        <CardDescription className="text-center">Enter your password to sign in to your account</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleLogin} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                className="pl-10"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={isLoading}
              />
            </div>
            {error && <p className="text-sm font-medium text-destructive">{error}</p>}
          </div>
          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Signing In...
              </>
            ) : (
              "Sign In"
            )}
          </Button>
        </form>
      </CardContent>
      <CardFooter className="flex flex-col gap-2">
        <p className="text-xs text-center text-muted-foreground">
          Protected by advanced encryption. Your security is our priority.
        </p>
        <div className="text-xs text-center text-muted-foreground">
          <Link href="/admin/login" className="text-primary hover:underline">
            Admin Login
          </Link>
        </div>
      </CardFooter>
    </Card>
  )
}
