"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

type AccountData = {
  api_id: string
  number: string
  password: string
  balance?: number // Make balance optional
}

export function ConfigModal({
  open,
  onOpenChange,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const [accountData, setAccountData] = useState<AccountData | null>(null)

  useEffect(() => {
    if (open) {
      const data = localStorage.getItem("accountData")
      if (data) {
        setAccountData(JSON.parse(data))
      }
    }
  }, [open])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Account Configuration</DialogTitle>
          <DialogDescription>Your account details are displayed below.</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {accountData ? (
            <div className="rounded-lg border p-4">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="font-medium">API ID:</div>
                <div>{accountData.api_id}</div>

                <div className="font-medium">Number:</div>
                <div>{accountData.number}</div>

                <div className="font-medium">Password:</div>
                <div>{accountData.password}</div>
              </div>
            </div>
          ) : (
            <p className="text-center text-muted-foreground">No account data found. Please create an account first.</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
