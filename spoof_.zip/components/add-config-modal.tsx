"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { toast } from "@/components/ui/use-toast"

type AccountData = {
  api_id: string
  number: string
  password: string
  balance: number
}

export function AddConfigModal({
  open,
  onOpenChange,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const [apiId, setApiId] = useState("")
  const [number, setNumber] = useState("")
  const [password, setPassword] = useState("")
  const [balance, setBalance] = useState("")

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    // Create account data object
    const accountData: AccountData = {
      api_id: apiId,
      number: number,
      password: password,
      balance: Number.parseFloat(balance),
    }

    // Save to localStorage
    localStorage.setItem("accountData", JSON.stringify(accountData))

    // Show success message
    toast({
      title: "Success",
      description: "Configuration added successfully",
    })

    // Close the modal
    onOpenChange(false)

    // Reset form
    setApiId("")
    setNumber("")
    setPassword("")
    setBalance("")
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add Configuration</DialogTitle>
          <DialogDescription>Enter your account configuration details manually.</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="apiId" className="text-right">
                API ID
              </Label>
              <Input
                id="apiId"
                value={apiId}
                onChange={(e) => setApiId(e.target.value)}
                className="col-span-3"
                required
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="number" className="text-right">
                Number
              </Label>
              <Input
                id="number"
                value={number}
                onChange={(e) => setNumber(e.target.value)}
                className="col-span-3"
                required
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="password" className="text-right">
                Password
              </Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="col-span-3"
                required
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="balance" className="text-right">
                Balance
              </Label>
              <Input
                id="balance"
                type="number"
                step="0.01"
                value={balance}
                onChange={(e) => setBalance(e.target.value)}
                className="col-span-3"
                required
              />
            </div>
          </div>

          <DialogFooter>
            <Button type="submit">Save Configuration</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
