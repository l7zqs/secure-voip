"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Loader2 } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

type AccountData = {
  api_id: string
  number: string
  password: string
}

export function BalanceModal({
  open,
  onOpenChange,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const [accountData, setAccountData] = useState<AccountData | null>(null)
  const [balance, setBalance] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (open) {
      const data = localStorage.getItem("accountData")
      if (data) {
        setAccountData(JSON.parse(data))
      } else {
        setError("No account data found. Please add your configuration first.")
      }
    } else {
      // Reset state when modal closes
      setBalance(null)
      setError(null)
    }
  }, [open])

  async function checkBalance() {
    if (!accountData) {
      setError("No account data found. Please add your configuration first.")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      // Use the real API endpoint
      const response = await fetch(
        `http://api.spoof.cam/api/index.php?action=user_get_balance&number=${accountData.number}&password=${accountData.password}`,
      )

      // Check if the response is ok
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`)
      }

      const data = await response.json()

      if (data.success) {
        setBalance(data.data.balance)
      } else {
        setError(data.message || "Failed to retrieve balance")
        toast({
          title: "Error",
          description: data.message || "Failed to retrieve balance",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error checking balance:", error)

      // Provide a fallback for development/testing
      if (process.env.NODE_ENV === "development") {
        console.log("Using mock data in development mode")
        setBalance("10.5000") // Mock balance for development
      } else {
        setError("Failed to connect to the server. Please try again.")
        toast({
          title: "Error",
          description: "Failed to connect to the server. Please try again.",
          variant: "destructive",
        })
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Check Balance</DialogTitle>
          <DialogDescription>Check your current account balance</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {error ? (
            <p className="text-center text-destructive">{error}</p>
          ) : balance ? (
            <div className="rounded-lg border p-6 text-center">
              <div className="text-sm text-muted-foreground mb-1">Your current balance is</div>
              <div className="text-3xl font-bold">${balance}</div>
            </div>
          ) : (
            <p className="text-center text-muted-foreground">Click the button below to check your balance.</p>
          )}

          <Button onClick={checkBalance} className="w-full" disabled={isLoading || !accountData}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Checking Balance...
              </>
            ) : (
              "Check Balance"
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
