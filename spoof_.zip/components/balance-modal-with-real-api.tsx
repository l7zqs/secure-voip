// Import necessary variables and functions
import { accountData } from "./path-to-accountData"

const fetchData = async () => {
  // Replace this:
  // const data = await mockBalanceCheck(accountData.number, accountData.password);

  // With this:
  const response = await fetch(
    `http://api.spoof.cam/api/index.php?action=user_get_balance&number=${accountData.number}&password=${accountData.password}`,
  )
  const balanceData = await response.json()
  return balanceData
}

// Usage of fetchData
fetchData().then((data) => {
  console.log(data)
})
