import type React from "react"
import "./globals.css"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Call VoIP Service | HD Voice & Video Calls",
  description: "Developed by Tasin | Secure, high-quality VoIP calls with low latency.",
  viewport: "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no",
  generator: "Next.js",
  applicationName: "Call VoIP Service",
  keywords: [
    "VoIP", "voice calls", "video calls", "SIP", "cloud telephony", 
    "Tasin", "WebRTC", "low-latency calls"
  ],
  themeColor: "#0066ff",
  authors: [
    { name: "Tasin" }
  ],
  creator: "Tasin",
  publisher: "Tasin",
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
      </head>
      <body className={`${inter.className} overflow-hidden`}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  )
}
