"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useState } from "react"
import { ConfigModal } from "@/components/config-modal"
import { AddConfigModal } from "@/components/add-config-modal"
import { BalanceModal } from "@/components/balance-modal"

export default function Dashboard() {
  const router = useRouter()
  const [isConfigOpen, setIsConfigOpen] = useState(false)
  const [isAddConfigOpen, setIsAddConfigOpen] = useState(false)
  const [isBalanceOpen, setIsBalanceOpen] = useState(false)

  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-4 bg-gradient-to-br from-slate-100 to-slate-200">
      <div className="w-full max-w-md text-center space-y-6">
        <h1 className="text-3xl font-bold">User Dashboard</h1>
        <p className="text-muted-foreground mb-6">Manage your account</p>

        <div className="grid grid-cols-1 gap-4">
          <Button onClick={() => setIsAddConfigOpen(true)} className="w-full">
            Add Config
          </Button>

          <Button onClick={() => router.push("/dashboard/change-number")} className="w-full" variant="outline">
            Change Number
          </Button>

          <Button onClick={() => setIsBalanceOpen(true)} className="w-full" variant="secondary">
            Check Balance
          </Button>

          <Button onClick={() => setIsConfigOpen(true)} className="w-full" variant="outline">
            View Config
          </Button>

          <Button onClick={() => router.push("/dashboard/call-history")} className="w-full" variant="secondary">
            Call History
          </Button>
        </div>

        <div className="pt-6">
          <Link href="/admin/login">
            <Button variant="ghost">Admin Login</Button>
          </Link>
        </div>
      </div>

      <ConfigModal open={isConfigOpen} onOpenChange={setIsConfigOpen} />
      <AddConfigModal open={isAddConfigOpen} onOpenChange={setIsAddConfigOpen} />
      <BalanceModal open={isBalanceOpen} onOpenChange={setIsBalanceOpen} />
    </div>
  )
}
