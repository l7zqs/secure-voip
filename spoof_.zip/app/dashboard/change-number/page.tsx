"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2 } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

type AccountData = {
  api_id: string
  number: string
  password: string
  balance: number
}

export default function ChangeNumber() {
  const router = useRouter()
  const [newNumber, setNewNumber] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [accountData, setAccountData] = useState<AccountData | null>(null)

  useEffect(() => {
    // Load account data from localStorage
    const data = localStorage.getItem("accountData")
    if (data) {
      setAccountData(JSON.parse(data))
    } else {
      toast({
        title: "Error",
        description: "No account data found. Please create an account first.",
        variant: "destructive",
      })
      router.push("/dashboard")
    }
  }, [router])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    if (!accountData) {
      toast({
        title: "Error",
        description: "No account data found. Please create an account first.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch(
        `http://api.spoof.cam/api/index.php?action=user_change_number&api_key=10cb6c3b-09e1-4c3e-b1a0-3f3ffd&new_number=${newNumber}&password=${accountData.password}&api_id=${accountData.api_id}`,
      )

      const data = await response.json()

      if (data.success) {
        // Update the account data in localStorage
        const updatedAccountData = {
          ...accountData,
          number: newNumber,
        }

        localStorage.setItem("accountData", JSON.stringify(updatedAccountData))

        toast({
          title: "Success",
          description: data.message || "Number changed successfully",
        })

        // Redirect back to dashboard
        router.push("/dashboard")
      } else {
        toast({
          title: "Error",
          description: data.message || "Failed to change number",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error changing number:", error)
      toast({
        title: "Error",
        description: "Failed to connect to the server. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-4 bg-gradient-to-br from-slate-100 to-slate-200">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">Change Number</CardTitle>
          <CardDescription className="text-center">Enter your new phone number</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="newNumber">New Number</Label>
              <Input
                id="newNumber"
                type="text"
                placeholder="Enter new phone number"
                value={newNumber}
                onChange={(e) => setNewNumber(e.target.value)}
                required
                disabled={isLoading}
              />
            </div>

            <Button type="submit" className="w-full" disabled={isLoading || !accountData}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Changing Number...
                </>
              ) : (
                "Change Number"
              )}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button variant="ghost" onClick={() => router.push("/dashboard")} disabled={isLoading}>
            Back to Dashboard
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
