"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2 } from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

type AccountData = {
  api_id: string
  number: string
  password: string
}

type CallRecord = {
  id: string
  date: string
  duration: string
  destination: string
  cost: string
}

export default function CallHistory() {
  const router = useRouter()
  const [accountData, setAccountData] = useState<AccountData | null>(null)
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [callRecords, setCallRecords] = useState<CallRecord[]>([])
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Load account data from localStorage
    const data = localStorage.getItem("accountData")
    if (data) {
      setAccountData(JSON.parse(data))
    } else {
      setError("No account data found. Please add your configuration first.")
      toast({
        title: "Error",
        description: "No account data found. Please add your configuration first.",
        variant: "destructive",
      })
    }

    // Set default date range (today)
    const today = new Date()
    const formattedDate = formatDate(today)
    setStartDate(`${formattedDate} 00:00:00`)
    setEndDate(`${formattedDate} 23:59:59`)
  }, [])

  function formatDate(date: Date): string {
    const day = String(date.getDate()).padStart(2, "0")
    const month = String(date.getMonth() + 1).padStart(2, "0")
    const year = date.getFullYear()
    return `${day}-${month}-${year}`
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    if (!accountData) {
      setError("No account data found. Please add your configuration first.")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      // Use the real API endpoint
      const response = await fetch(
        `http://api.spoof.cam/api/index.php?action=user_get_cdr&number=${accountData.number}&password=${accountData.password}&start_date=${startDate}&end_date=${endDate}`,
      )

      // Check if the response is ok
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`)
      }

      const data = await response.json()

      if (data.success) {
        setCallRecords(data.data?.records || [])

        if (data.data?.records?.length === 0) {
          setError("No call records found for the selected date range.")
        }
      } else {
        setError(data.message || "Failed to retrieve call history")
        toast({
          title: "Error",
          description: data.message || "Failed to retrieve call history",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error fetching call history:", error)

      // Provide fallback data for development/testing
      if (process.env.NODE_ENV === "development") {
        console.log("Using mock data in development mode")
        // Mock call records for development
        setCallRecords([
          {
            id: "1",
            date: "25-03-2023 10:15:22",
            duration: "00:05:32",
            destination: "+1 (555) 123-4567",
            cost: "0.75",
          },
          {
            id: "2",
            date: "25-03-2023 14:22:10",
            duration: "00:02:45",
            destination: "+1 (555) 987-6543",
            cost: "0.45",
          },
          {
            id: "3",
            date: "25-03-2023 18:05:33",
            duration: "00:10:18",
            destination: "+1 (555) 456-7890",
            cost: "1.25",
          },
        ])
      } else {
        setError("Failed to connect to the server. Please try again.")
        toast({
          title: "Error",
          description: "Failed to connect to the server. Please try again.",
          variant: "destructive",
        })
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 to-slate-200 p-4">
      <div className="mx-auto max-w-4xl">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Call History</CardTitle>
            <CardDescription>View your call history for a specific date range</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="startDate">Start Date</Label>
                  <Input
                    id="startDate"
                    type="text"
                    placeholder="DD-MM-YYYY HH:MM:SS"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    required
                    disabled={isLoading}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="endDate">End Date</Label>
                  <Input
                    id="endDate"
                    type="text"
                    placeholder="DD-MM-YYYY HH:MM:SS"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    required
                    disabled={isLoading}
                  />
                </div>
              </div>

              <Button type="submit" className="w-full" disabled={isLoading || !accountData}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Loading Call History...
                  </>
                ) : (
                  "View Call History"
                )}
              </Button>
            </form>

            {error && <p className="mt-4 text-center text-destructive">{error}</p>}

            {callRecords.length > 0 && (
              <div className="mt-6 rounded-md border">
                <Table>
                  <TableCaption>Call history for the selected period</TableCaption>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date & Time</TableHead>
                      <TableHead>Destination</TableHead>
                      <TableHead>Duration</TableHead>
                      <TableHead className="text-right">Cost</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {callRecords.map((record) => (
                      <TableRow key={record.id}>
                        <TableCell>{record.date}</TableCell>
                        <TableCell>{record.destination}</TableCell>
                        <TableCell>{record.duration}</TableCell>
                        <TableCell className="text-right">${record.cost}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-center">
            <Button variant="ghost" onClick={() => router.push("/dashboard")} disabled={isLoading}>
              Back to Dashboard
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
